<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{{ $title }}</title>
    
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    
    
    <link rel="stylesheet" href="{{ URL::asset('icon/style.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('css/style.css') }}">
    
</head>
<body>
    
<div class="container-form">
        <div class="header">
            <div class="logo-title">
                <img src="{{ URL::asset('image/logo_lunaraweb.png') }}" alt="">
                <h2>Lunara Beauty Care</h2>
            </div>
            <div class="menu">
                <a href="/"><li class="module-login">Masuk</li></a>
                <a href="/register"><li class="module-register active">Daftar</li></a>
            </div>
        </div>
        
        <form action="/register" method="post" class="form">
          @csrf
            <div class="welcome-form"><h1>Selamat Datang di</h1><h2>Lunara Beauty Care</h2></div>
            
            <div class="user line-input">
                <label class="lnr lnr-envelope"></label>
                <input type="email" class="@error('email')is-invalid @enderror" placeholder="Masukkan Email" name="email" autocomplete="off">
                @error('email')
              <div class="invalid-feedback">
                {{ $message }}
              </div>
              @enderror
            </div>

            <div class="user line-input">
                <label class="lnr lnr-user"></label>
                <input type="text" class="@error('username')is-invalid @enderror" placeholder="Username" name="username" autocomplete="off">
                @error('username')
              <div class="invalid-feedback">
                {{ $message }}
              </div>
              @enderror
            </div>

            <div class="user line-input">
              <label class="lnr lnr-user"></label>
              <input type="number" class="@error('nomer')is-invalid @enderror" name="nomer" placeholder="No Hp" autocomplete="off" pattern="(\+62|62|0)8[1-9][0-9]{6,12}$">

              @error('nomer')
              <div class="invalid-feedback">
                {{ $message }}
              </div>
              @enderror
          </div>

            <div class="password line-input">
                <label class="lnr lnr-lock"></label>
                <input type="password" class="@error('password')is-invalid @enderror" placeholder="Kata Sandi" name="password" autocomplete="off">
                @error('password')
              <div class="invalid-feedback">
                {{ $message }}
              </div>
              @enderror
            </div>

            <div class="password line-input">
              <label class="lnr lnr-lock"></label>
                <input type="datetime-local" class="form-control" placeholder="Enter Date">
          </div>

          <script type="text/javascript">
            $(function() {
                $('#datepicker').datepicker();
            });
          </script> 
            
            <button type="submit">Daftar<label class="lnr lnr-chevron-right"></label></button>
               
    </form>
    </div>

    
    <script src="js/jquery.js"></script>
    <script src="js/script.js"></script>
</body>
</html>